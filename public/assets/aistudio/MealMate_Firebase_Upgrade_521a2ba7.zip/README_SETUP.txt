MEALMATE — FIREBASE CONNECTED MVP
=================================

WHAT THIS PACKAGE DOES
- Preserves the existing MealMate green/cream design and menu cards.
- Adds Firebase Email/Password student sign-up and sign-in.
- Saves orders in Cloud Firestore.
- Shows new orders in the vendor dashboard in real time.
- Lets an authorised vendor mark orders Ready and Picked up.
- Stores menu stock and pickup-slot reservations in Firestore.
- Checks stock and slot capacity inside a Firestore transaction before accepting an order.
- Removes the fake UPI payment screen: orders are Pay at pickup until a payment gateway is properly configured.

IMPORTANT MVP LIMITS
- This is a Firebase client-side MVP, not a fully managed production service. Before taking public/high-volume orders, add a trusted server/Cloud Function for order creation, stronger validation, rate limiting, monitoring and operational recovery. Firestore rules protect ownership and role access, but this package is not a substitute for a security review.
- Online UPI payment is intentionally not enabled. No money is collected by this site.
- Menu data is seeded from the existing prototype menu; verify every item, price, vendor and stock quantity with the actual campus vendors before going live.
- The initial pickup windows are demo defaults (12:30, 12:40 and 12:50 PM) and need to be updated to actual operating hours.

FILES
- index.html      Main MealMate page and account/order UI
- style.css       Existing design plus responsive account styles
- app.js          Firebase Authentication + Firestore integration
- firestore.rules Security rules for users, menu, slots and orders

STEP 1 — PUBLISH FIRESTORE RULES
1. Open Firebase Console > MealMate > Firestore Database > Rules.
2. Replace the editor contents with the complete contents of firestore.rules in this folder.
3. Click Publish.
4. Do not switch to Test mode.

STEP 2 — DEPLOY THE WEBSITE TO YOUR EXISTING NETLIFY SITE
1. Keep a backup of the current deployed site.
2. Open your Netlify site: elaborate-begonia-f76d14.
3. Use the manual deploy / Netlify Drop workflow for the existing site.
4. Upload the three website files from this folder: index.html, style.css, app.js.
   (firestore.rules and this README are setup files; they are not website assets.)
5. Wait for the deployment to finish, then open the public URL and hard-refresh.

STEP 3 — CREATE THE FIRST VENDOR ACCOUNT
1. Open the deployed MealMate website.
2. Click Sign in > Create student account and register using the email address that the vendor will use.
3. In Firebase Console > Authentication > Users, find that email and copy its User UID.
4. Open Firestore Database > Data. Create a collection named users if it does not exist.
5. Create a document whose document ID is exactly that User UID.
6. Add fields:
   uid   (string) = the same User UID
   name  (string) = vendor display name
   email (string) = vendor email
   role  (string) = vendor
7. Keep the existing createdAt/updatedAt fields if they exist; the role field is the important admin assignment.
8. Sign out and sign back in on the website. The Vendor portal should now open.

SECURITY NOTE: Do not let users choose their own role. Only assign role=vendor manually in the Firebase Console as project administrator. Student sign-up always creates role=student, and the Firestore rules prevent a student from changing it.

STEP 4 — PUBLISH MENU AND PICKUP SLOTS
1. Sign in with the authorised vendor account.
2. Open Vendor portal.
3. Click “Publish starter menu & pickup slots” once.
4. This creates the starter menu collection and the three pickup slot documents. It will not overwrite an existing menu.
5. Use “Add 5 portions” only as a test stock adjustment for Rajma rice bowl. Update other stock from Firestore Data as needed.

STEP 5 — TEST THE STUDENT ORDER FLOW
1. Open a private/incognito browser window or another browser.
2. Create a separate student account and sign in.
3. Add an available item to the basket, select a pickup slot and place the pre-order.
4. Confirm that an order document appears in Firestore > orders.
5. In the vendor account, open Vendor portal. The order should appear automatically.
6. Mark it Ready, then Picked up. The student can see the confirmation after placing the order; a dedicated student order-history screen is a next enhancement.
7. Check that the menu stock and slot reserved count decreased by one.

TROUBLESHOOTING
- “Missing or insufficient permissions”: verify that firestore.rules were published, the vendor users/{UID} document has role=vendor, and the vendor has signed out/in after the role assignment.
- “Pickup slots are not published yet”: vendor must publish the starter menu and slots first.
- “Item is no longer available” or “slot is full”: select another item/slot or ask the vendor to update stock/capacity.
- If the browser shows a module/CORS error, confirm the three website files were deployed to the Netlify site root and the page is loaded over HTTPS.

Do not share Firebase passwords, service-account private keys, or account recovery codes.
