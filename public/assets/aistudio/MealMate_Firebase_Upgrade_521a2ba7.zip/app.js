import { initializeApp } from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js';
import {
  getAuth, onAuthStateChanged, createUserWithEmailAndPassword,
  signInWithEmailAndPassword, signOut, sendEmailVerification
} from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js';
import {
  getFirestore, collection, doc, getDoc, getDocs, onSnapshot,
  query, orderBy, limit, runTransaction, serverTimestamp, setDoc, updateDoc
} from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js';

// MealMate Firebase web configuration supplied by the project owner.
const firebaseConfig = {
  apiKey: 'AIzaSyDz-O0dMJ2AsU9hu4MyzTlW3OWbCunLR74',
  authDomain: 'mealmate-d6e7e.firebaseapp.com',
  projectId: 'mealmate-d6e7e',
  storageBucket: 'mealmate-d6e7e.firebasestorage.app',
  messagingSenderId: '126428995863',
  appId: '1:126428995863:web:113c10ca2baf98c9229752',
  measurementId: 'G-LTFLJ990HW'
};

const firebaseApp = initializeApp(firebaseConfig);
const auth = getAuth(firebaseApp);
const db = getFirestore(firebaseApp);

const starterMeals = [
  {id:'1',n:'Rajma rice bowl',p:89,e:'🍛',tag:'BESTSELLER',type:'veg',avail:6,place:'Green Leaf Canteen'},
  {id:'2',n:'Paneer tikka wrap',p:99,e:'🌯',tag:'QUICK PICK',type:'quick',avail:9,place:'Green Leaf Canteen'},
  {id:'3',n:'Masala dosa combo',p:75,e:'🥞',tag:'VEG',type:'veg',avail:4,place:'South Square'},
  {id:'4',n:'Chicken biryani bowl',p:129,e:'🍗',tag:'POPULAR',type:'quick',avail:0,place:'Green Leaf Canteen'},
  {id:'5',n:'Aloo paratha & curd',p:65,e:'🫓',tag:'VEG',type:'veg',avail:7,place:'North Block Café'},
  {id:'6',n:'Cold coffee',p:55,e:'🥤',tag:'FAST',type:'quick',avail:12,place:'North Block Café'},
  {id:'7',n:'Chole bhature',p:85,e:'🥘',tag:'CAMPUS FAV',type:'veg',avail:8,place:'North Block Café'},
  {id:'8',n:'Veggie burger & fries',p:110,e:'🍔',tag:'QUICK PICK',type:'quick',avail:10,place:'South Square'},
  {id:'9',n:'Hakka noodles',p:95,e:'🍜',tag:'HOT',type:'veg',avail:5,place:'Green Leaf Canteen'},
  {id:'10',n:'Grilled chicken sandwich',p:119,e:'🥪',tag:'PROTEIN',type:'quick',avail:6,place:'North Block Café'},
  {id:'11',n:'Fruit yogurt bowl',p:79,e:'🍓',tag:'FRESH',type:'veg',avail:9,place:'South Square'},
  {id:'12',n:'Lemon iced tea',p:40,e:'🍋',tag:'REFRESHING',type:'quick',avail:15,place:'Green Leaf Canteen'}
];
const pickupSlots = [
  {id:'12-30',label:'12:30 – 12:40 PM',capacity:8},
  {id:'12-40',label:'12:40 – 12:50 PM',capacity:8},
  {id:'12-50',label:'12:50 – 1:00 PM',capacity:8}
];
let meals = [...starterMeals], cart = JSON.parse(localStorage.getItem('mealmate-cart') || '[]');
let filter = 'all', currentUser = null, currentRole = 'guest', menuUnsub = null, ordersUnsub = null;
const $ = s => document.querySelector(s), money = n => '₹' + Number(n || 0);
const safe = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function toast(message) { const t=$('#toast'); t.textContent=message; t.classList.add('show'); setTimeout(()=>t.classList.remove('show'),2800); }
function panel(id,on) { $(id).classList.toggle('open',on); $('#scrim').classList.toggle('show',on); }
function showAuth(message='') { $('#authMessage').textContent=message; $('#auth').classList.add('open'); }
function hideAuth() { $('#auth').classList.remove('open'); }
function persistCart() { localStorage.setItem('mealmate-cart',JSON.stringify(cart)); $('#cartCount').textContent=cart.length; }
function itemFromDoc(d) { const x=d.data(); return {id:d.id,n:x.name,p:x.price,e:x.emoji||'🍽️',tag:x.tag||'AVAILABLE',type:x.type||'veg',avail:Number(x.available||0),place:x.vendorName||'Campus kitchen'}; }

function renderMenu() {
  const list = filter==='all' ? meals : meals.filter(m=>m.type===filter);
  $('#menuGrid').innerHTML = list.map(m=>`<article class="meal"><div class="meal-img">${safe(m.e)}</div><span class="tag ${m.avail>0?'':'sold'}">${m.avail>0?safe(m.tag):'SOLD OUT'}</span><h3>${safe(m.n)}</h3><p>${safe(m.place)} · ${m.avail>0?m.avail+' left today':'check back soon'}</p><div class="meal-bottom"><b>${money(m.p)}</b><button class="add" data-id="${safe(m.id)}" ${m.avail<=0?'disabled':''}>+</button></div></article>`).join('');
  document.querySelectorAll('.add').forEach(b=>b.onclick=()=>add(b.dataset.id));
}
function add(id) { if(!cart.includes(String(id))) cart.push(String(id)); persistCart(); renderCart(); toast('Added to your basket'); }
function slotOptions() {
  return pickupSlots.map(s=>`<option value="${s.id}">${s.label} · capacity ${s.capacity}</option>`).join('');
}
function renderCart() {
  const items=cart.map(id=>meals.find(m=>m.id===id)).filter(Boolean);
  $('#cartItems').innerHTML=items.length?items.map(m=>`<div class="cart-item"><span>${safe(m.e)}</span><div><b>${safe(m.n)}</b><small>${safe(m.place)} · ${money(m.p)}</small><button class="remove" data-id="${safe(m.id)}">Remove</button></div></div>`).join(''):'<p class="muted" style="margin-top:25px">Your basket is waiting for something delicious.</p>';
  $('#slotSelect').innerHTML=slotOptions();
  $('#slotHint').textContent=items.length?'Pickup slots are limited. Availability is checked again when you place the order.':'Add an item to choose a pickup slot.';
  const total=items.reduce((a,m)=>a+m.p,0); $('#total').textContent=money(total); $('#payTotal').textContent=money(total);
  $('#checkout').disabled=!items.length; $('#checkout').style.opacity=items.length?1:.45;
  document.querySelectorAll('.remove').forEach(b=>b.onclick=()=>{cart=cart.filter(id=>id!==b.dataset.id);persistCart();renderCart();});
}
function renderAccount() {
  const b=$('#accountButton');
  b.textContent=currentUser ? (currentUser.email.split('@')[0]+' · Sign out') : 'Sign in';
  b.title=currentUser?currentUser.email:'Student sign in';
}
function setAuthMessage(message, isError=false) { const el=$('#authMessage'); el.textContent=message; el.style.color=isError?'#a33':'#126b55'; }

async function submitAuth(e) {
  e.preventDefault(); const mode=$('#authMode').value, email=$('#authEmail').value.trim(), password=$('#authPassword').value;
  const name=$('#authName').value.trim();
  if(!email||!password) return setAuthMessage('Enter your email and password.',true);
  if(password.length<6) return setAuthMessage('Use a password with at least 6 characters.',true);
  try {
    setAuthMessage('Please wait…');
    if(mode==='signup') {
      if(!name) return setAuthMessage('Enter your name to create an account.',true);
      const credential=await createUserWithEmailAndPassword(auth,email,password);
      await setDoc(doc(db,'users',credential.user.uid),{uid:credential.user.uid,name,email,role:'student',createdAt:serverTimestamp(),updatedAt:serverTimestamp()});
      try { await sendEmailVerification(credential.user); } catch(e) { console.warn('Verification email not sent',e); }
      setAuthMessage('Account created. You are signed in. Check your email for a verification link.');
    } else {
      await signInWithEmailAndPassword(auth,email,password);
      setAuthMessage('Signed in successfully.');
    }
    setTimeout(hideAuth,700);
  } catch(err) { setAuthMessage(authError(err.code),true); }
}
function authError(code) {
  const messages={'auth/email-already-in-use':'This email already has an account. Sign in instead.','auth/invalid-email':'Please enter a valid email address.','auth/weak-password':'Choose a stronger password.','auth/invalid-credential':'Email or password is incorrect.','auth/user-not-found':'No account found. Create an account first.','auth/too-many-requests':'Too many attempts. Please wait and try again.'};
  return messages[code] || 'Could not sign in. Please check your details and try again.';
}

function watchMenu() {
  if(menuUnsub) menuUnsub();
  menuUnsub=onSnapshot(collection(db,'menu'),snap=>{
    if(!snap.empty) { meals=snap.docs.map(itemFromDoc).sort((a,b)=>Number(a.id)-Number(b.id)); renderMenu(); renderCart(); }
  },err=>{console.error(err);toast('Could not load live menu. Check your connection.');});
}
function watchVendorOrders() {
  if(ordersUnsub) ordersUnsub();
  const q=query(collection(db,'orders'),orderBy('createdAt','desc'),limit(100));
  ordersUnsub=onSnapshot(q,snap=>renderVendorOrders(snap.docs),err=>{console.error(err);toast('Could not load vendor orders.');});
}
function renderVendorOrders(docs) {
  const rows=docs.map(d=>({id:d.id,...d.data()}));
  $('#vendorOrders').innerHTML=rows.length?rows.map(o=>{
    const mealNames=(o.items||[]).map(i=>safe(i.name)).join(', ');
    return `<div class="v-order"><span>${o.status==='Ready'?'🟢':o.status==='Picked up'?'☑️':'🟡'}</span><div><b>${mealNames}</b><small>${safe(o.customerName||o.email||'Student')} · ${safe(o.slotLabel||'Pickup slot')} · ${money(o.total)}</small></div><button class="status-button ${o.status==='Ready'?'ready':''}" data-order="${safe(o.id)}" data-status="${safe(o.status)}">${o.status==='Ready'?'Mark picked up':o.status==='Picked up'?'Collected':'Mark ready'}</button></div>`;
  }).join(''):'<p class="muted" style="padding:18px">No orders yet. New student pre-orders will appear here.</p>';
  $('#orderTotal').textContent=rows.length;
  $('#readyCount').textContent=rows.filter(o=>o.status==='Ready').length;
  document.querySelectorAll('.status-button').forEach(b=>b.onclick=async()=>{
    const next=b.dataset.status==='Ready'?'Picked up':'Ready';
    try { await updateDoc(doc(db,'orders',b.dataset.order),{status:next,updatedAt:serverTimestamp()}); toast(next==='Ready'?'Order marked ready':'Order marked collected'); }
    catch(err){console.error(err);toast('Status update failed. Check vendor access.');}
  });
}

async function openVendor() {
  if(!currentUser) return showAuth('Sign in with your vendor account to open the kitchen dashboard.');
  if(currentRole!=='vendor') return toast('This account is not authorised as a vendor. Ask the MealMate administrator to assign vendor access.');
  $('#vendor').classList.add('open'); watchVendorOrders();
}
async function seedStarterData() {
  if(currentRole!=='vendor') return;
  try {
    const snap=await getDocs(collection(db,'menu'));
    if(!snap.empty) return toast('Menu already exists. Use the menu controls to update stock.');
    for(const m of starterMeals) await setDoc(doc(db,'menu',m.id),{name:m.n,price:m.p,emoji:m.e,tag:m.tag,type:m.type,available:m.avail,vendorName:m.place,active:true,updatedAt:serverTimestamp()});
    for(const s of pickupSlots) await setDoc(doc(db,'slots',s.id),{label:s.label,capacity:s.capacity,reserved:0,updatedAt:serverTimestamp()});
    toast('Starter menu and pickup slots published.');
  } catch(err){console.error(err);toast('Could not publish starter menu. Check vendor permissions.');}
}

async function placeOrder() {
  if(!cart.length) return;
  if(!currentUser) { panel('#payment',false); showAuth('Please sign in or create a student account before placing an order.'); return; }
  if(currentRole==='vendor') { toast('Please use a student account to place an order.'); return; }
  const selected=pickupSlots.find(s=>s.id===$('#slotSelect').value) || pickupSlots[0];
  const chosen=cart.map(id=>meals.find(m=>m.id===id)).filter(Boolean);
  if(!chosen.length) return toast('Your basket is empty.');
  const orderRef=doc(collection(db,'orders'));
  const slotRef=doc(db,'slots',selected.id);
  try {
    await runTransaction(db,async tx=>{
      const slotSnap=await tx.get(slotRef);
      if(!slotSnap.exists()) throw new Error('SLOTS_NOT_PUBLISHED');
      const slot=slotSnap.data();
      if(Number(slot.reserved||0)>=Number(slot.capacity||0)) throw new Error('SLOT_FULL');
      const menuRefs=chosen.map(m=>doc(db,'menu',m.id));
      const menuSnaps=[]; for(const ref of menuRefs) menuSnaps.push(await tx.get(ref));
      menuSnaps.forEach((snap,i)=>{if(!snap.exists()||Number(snap.data().available||0)<1||snap.data().active===false) throw new Error('ITEM_UNAVAILABLE:'+chosen[i].n);});
      const total=chosen.reduce((sum,m)=>sum+m.p,0);
      const orderItems=chosen.map(m=>({id:m.id,name:m.n,price:m.p,emoji:m.e,vendorName:m.place}));
      tx.set(orderRef,{uid:currentUser.uid,email:currentUser.email,customerName:currentUser.displayName||currentUser.email.split('@')[0],items:orderItems,menuIds:chosen.map(m=>m.id),total,slotId:selected.id,slotLabel:selected.label,status:'Accepted',paymentStatus:'Pay at pickup',createdAt:serverTimestamp(),updatedAt:serverTimestamp()});
      tx.update(slotRef,{reserved:Number(slot.reserved||0)+1,lastReservedBy:orderRef.id,updatedAt:serverTimestamp()});
      menuSnaps.forEach((snap,i)=>tx.update(menuRefs[i],{available:Number(snap.data().available)-1,lastReservedBy:orderRef.id,updatedAt:serverTimestamp()}));
    });
    const code='MM-'+orderRef.id.slice(-5).toUpperCase();
    $('#token').textContent=code; $('#confirmText').textContent=`${chosen.map(m=>m.n).join(' & ')} is reserved for ${selected.label}. Show ${code} at collection. Payment is due at pickup.`;
    cart=[];persistCart();renderCart();panel('#payment',false);$('#confirmation').classList.add('open');
  } catch(err) {
    console.error(err); panel('#payment',false);
    const msg=err.message==='SLOT_FULL'?'That pickup slot is full. Please choose another slot.':err.message==='SLOTS_NOT_PUBLISHED'?'Pickup slots are not published yet. Please contact the vendor.':err.message.startsWith('ITEM_UNAVAILABLE:')?`${err.message.split(':')[1]} is no longer available.`:'Could not place your order. Please try again.';
    toast(msg); renderCart();
  }
}

onAuthStateChanged(auth,async user=>{
  currentUser=user; currentRole='guest';
  if(user) {
    try { const profile=await getDoc(doc(db,'users',user.uid)); currentRole=profile.exists()?(profile.data().role||'student'):'student'; }
    catch(e){console.error(e);currentRole='student';}
  }
  renderAccount();
  if(currentUser && currentRole==='vendor') $('#vendorAccessHint').textContent='Vendor access enabled for this account.';
  else $('#vendorAccessHint').textContent='Vendor accounts must be authorised by the MealMate administrator.';
});

// UI events
$('.cart-button').onclick=()=>{renderCart();panel('#cart',true);};
$('#scrim').onclick=()=>{panel('#cart',false);panel('#payment',false);};
document.querySelectorAll('.close').forEach(b=>b.onclick=()=>{panel('#cart',false);panel('#payment',false);});
$('#checkout').onclick=()=>{if(!cart.length)return;panel('#cart',false);panel('#payment',true);};
$('#pay').textContent='Place pre-order · pay at pickup'; $('#pay').onclick=placeOrder;
document.querySelectorAll('.modal-close').forEach(b=>b.onclick=()=>document.querySelectorAll('.modal').forEach(m=>m.classList.remove('open')));
document.querySelectorAll('.vendor-trigger').forEach(b=>b.onclick=openVendor);
document.querySelectorAll('.filter').forEach(b=>b.onclick=()=>{filter=b.dataset.filter;document.querySelectorAll('.filter').forEach(x=>x.classList.toggle('active',x===b));renderMenu();});
$('#shareButton').onclick=async()=>{try{await navigator.clipboard.writeText('MM-DGU20');}catch{}toast('Your referral code MM-DGU20 is ready to share');};
$('#accountButton').onclick=async()=>{if(currentUser){try{await signOut(auth);toast('Signed out');}catch(e){toast('Could not sign out');}}else showAuth();};
$('#authForm').addEventListener('submit',submitAuth);
$('#authMode').onchange=()=>{const signup=$('#authMode').value==='signup';$('#nameField').hidden=!signup;$('#authSubmit').textContent=signup?'Create account':'Sign in';setAuthMessage('');};
$('#authClose').onclick=hideAuth;
$('#seedMenu').onclick=seedStarterData;
$('#restock').onclick=async()=>{
  if(currentRole!=='vendor')return;
  try{const ref=doc(db,'menu','1');const snap=await getDoc(ref);if(!snap.exists())return toast('Publish the starter menu first.');await updateDoc(ref,{available:Number(snap.data().available||0)+5,updatedAt:serverTimestamp()});toast('5 portions added to Rajma rice bowl.');}
  catch(e){console.error(e);toast('Could not update stock.');}
};

persistCart();renderMenu();renderCart();renderAccount();watchMenu();
